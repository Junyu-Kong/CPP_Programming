#include "Actor.h"
#include "StudentWorld.h"
#include "GameConstants.h"
#include <cstdlib>
#include <vector>

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

const int STEP = 2;
const int LEFT = 180;
const int RIGHT = 0;
const int UP = 90;
const int DOWN = 270;

// Actor functions 
int Actor::updateDir(int dir, int x, int y)
{	 
	if (dir == RIGHT)
	{	
		// check if direction needs to be changed
		if (x > VIEW_WIDTH - SPRITE_WIDTH - STEP || this->getWorld()->getGridItem((x + SPRITE_WIDTH - 1 + STEP) / 16, y / 16) == Board::empty)
		{
			//cheack if the actor can move up
			if (y <= VIEW_HEIGHT - SPRITE_HEIGHT - STEP && this->getWorld()->getGridItem(x / 16, (y + SPRITE_HEIGHT - 1 + STEP) / 16) != Board::empty)
				return UP;
			return DOWN;
		}
		return dir;
	}
	else if (dir == LEFT)
	{
		// check if direction needs to be changed
		if (x < STEP || this->getWorld()->getGridItem((x - STEP) / 16, y / 16) == Board::empty)
		{
			//cheack if the actor can move up
			if (y <= VIEW_HEIGHT - SPRITE_HEIGHT - STEP && this->getWorld()->getGridItem(x / 16, (y + SPRITE_HEIGHT - 1 + STEP) / 16) != Board::empty)
				return UP;
			return DOWN;
		}
		return dir;
	}
	else if (dir == UP)
	{
		// check if direction needs to be changed
		if (y > VIEW_HEIGHT - SPRITE_HEIGHT - STEP || this->getWorld()->getGridItem(x / 16, (y + SPRITE_HEIGHT - 1 + STEP) / 16) == Board::empty)
		{
			//cheack if the actor can move right
			if (x <= VIEW_WIDTH - SPRITE_WIDTH - STEP && this->getWorld()->getGridItem((x + SPRITE_WIDTH - 1 + STEP) / 16, y / 16) != Board::empty)
				return RIGHT;
			return LEFT;
		}
		return dir;
	}
	else if (dir == DOWN)
	{
		// check if direction needs to be changed
		if (y < STEP || this->getWorld()->getGridItem(x / 16, (y - STEP) / 16) == Board::empty)
		{
			//cheack if the actor can move right
			if (x <= VIEW_WIDTH - SPRITE_WIDTH - STEP && this->getWorld()->getGridItem((x + SPRITE_WIDTH - 1 + STEP) / 16, y / 16) != Board::empty)
				return RIGHT;
			return LEFT;
		}
		return dir;
	}
	return dir;
}

bool Actor::landOn(Avatar* actor) const
{
	if (actor != nullptr && actor->getX() == getX() && actor->getY() == getY() && actor->getWait())
		return true;
	return false;
}

bool Actor::moveOn(Avatar* actor) const
{
	if (actor != nullptr && actor->getX() == getX() && actor->getY() == getY() && !actor->getWait())
		return true;
	return false;
}

bool Actor::cross(Actor* actor) const
{
	if (actor != nullptr && actor->getX() == getX() && actor->getY() == getY())
		return true;
	return false;
}

// Avatar functions 
void Avatar::doSomething(int num)
{
	// part 1
	if (m_wait_to_roll)
	{
		// 1.a
		setDir(updateDir(getDir(), getX(), getY()));
		if (getDir() == LEFT)
			setDirection(LEFT);
		else
			setDirection(RIGHT);

		// 1.b
		int action = getWorld()->getAction(num);
		
		// 1.c
		if (action == ACTION_ROLL)
		{
			int die_roll = rand() % 10 + 1;
			m_ticks_to_move = die_roll * 8;
			m_wait_to_roll = false;
		}

		// 1.d
		else if (action == ACTION_FIRE && m_vortex)
		{
			// NEED SOME WORK HERE 
			getWorld()->playSound(SOUND_PLAYER_FIRE);
			m_vortex = false;
		}

		// 1.e
		else
			return;
		
	}

	// part 2
	if (!m_wait_to_roll)
	{	
		m_newPlayer = true;

		// 2.c
		setDir(updateDir(getDir(), getX(), getY()));
		if (getDir() == LEFT)
			setDirection(LEFT);
		else
			setDirection(RIGHT);

		// 2.d
		moveAtAngle(getDir(), 2);

		// 2.e
		m_ticks_to_move--;

		// 2.f
		if (m_ticks_to_move == 0)
			m_wait_to_roll = true;
	}
}

// Coin functions 
void BlueCoin::sound() const
{
	getWorld()->playSound(SOUND_GIVE_COIN);
}

void RedCoin::sound() const
{
	getWorld()->playSound(SOUND_TAKE_COIN);
}

void Coin::doSomething(int coin)
{
	// part 1
	if (!getLive())
		return;

	// part 2
	Peach* p = getWorld()->getPeach();
	Yoshi* y = getWorld()->getYoshi();

	if (landOn(p) && p->getNew())
	{
		p->addCoin(coin);
		sound();
		p->setNew(false);
	}
	if (landOn(y) && y->getNew())
	{
		y->addCoin(coin);
		sound();
		y->setNew(false);
	}

}

// Star functions 
void Star::doSomething()
{
	Peach* p = getWorld()->getPeach();
	Yoshi* y = getWorld()->getYoshi();

	if (cross(p) && p->getNew())
	{
		if (p->getCoin() >= 20)
		{
			p->addCoin(-20);
			p->addStar(1);
			getWorld()->playSound(SOUND_GIVE_STAR);
		}
		p->setNew(false);
	}
	if (cross(y) && y->getNew())
	{
		if (y->getCoin() >= 20)
		{
			y->addCoin(-20);
			y->addStar(1);
			getWorld()->playSound(SOUND_GIVE_STAR);
		}
		y->setNew(false);
	}
}

// Direction functions 
void Direction::doSomething()
{
	Peach* p = getWorld()->getPeach();
	Yoshi* y = getWorld()->getYoshi();

	if (cross(y))
	{
		p->setDir(getDirection());
	}
	if (cross(y))
	{
		y->setDir(getDirection());
	}
}

// Bank functions 
void Bank::doSomething()
{
	StudentWorld* sw = getWorld();
	std::vector <Avatar*> avatars;
	avatars.push_back(sw->getPeach());
	avatars.push_back(sw->getYoshi());

	for (std::vector<Avatar*>::iterator a = avatars.begin(); a != avatars.end(); a++)
	{
		if (landOn(*a))
		{
			(*a)->addCoin(sw->getBank());
			sw->clearBank();
			sw->playSound(SOUND_WITHDRAW_BANK);
		}
		else if (moveOn(*a))
		{
			int coin = (*a)->getCoin();
			if (coin < 5)
			{
				sw->addBank(coin);
				(*a)->addCoin(coin * -1);
			}
			else
			{
				sw->addBank(5);
				(*a)->addCoin(-5);
			}
			sw->playSound(SOUND_DEPOSIT_BANK);
		}
	}
}