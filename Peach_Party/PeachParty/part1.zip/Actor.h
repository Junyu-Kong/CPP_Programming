#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "GameConstants.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class StudentWorld;
class Avatar;

class Actor : public GraphObject
{
public:
	Actor(int imageID, int startX, int startY, StudentWorld* world, int dir = right, int depth = 0, double size = 1.0)
		:GraphObject(imageID, startX, startY, dir, depth, size), m_world(world) {}
	virtual ~Actor(){}
	virtual void doSomething() = 0;

	// help functions
	bool moveOn(Avatar* actor) const;
	bool landOn(Avatar* actor) const;
	bool cross(Actor* actor) const;

	// getters
	int getDir() const { return m_walk_dir; }  // walking direction
	bool getLive() const { return m_alive; }
	StudentWorld* getWorld() const { return m_world; }
	virtual bool impactable() const { return false; }

	// setters
	void setDir(int dir) { m_walk_dir = dir; }  // walking direction
	void setLive(bool live) { m_alive = live; }
	int updateDir(int dir, int x, int y);

private:
	StudentWorld* m_world;
	int m_walk_dir = right;
	bool m_alive = true;
};

// Avatar
class Avatar : public Actor
{
public:
	Avatar(int imageID, int startX, int startY, StudentWorld* world)
		:Actor(imageID, startX, startY, world) {}
	virtual ~Avatar() {}
	virtual void doSomething() = 0;
	void doSomething(int playerNum);

	// getter
	int getStar() const { return m_star; }
	int getCoin() const { return m_coin; }
	bool getWait() const { return m_wait_to_roll; }
	bool getNew() const { return m_newPlayer; }
	int getDie() const { return (m_ticks_to_move + 4) / 8; }
	int getVor() const { return m_vortex; }

	// setter
	void addStar(int num) { m_star += num; }
	void addCoin(int num) { m_coin += num; }
	void setNew(bool newP) { m_newPlayer = newP; }

private:
	int m_coin = 0;
	int m_star = 0;
	bool m_vortex = false;
	int m_ticks_to_move = 0;
	bool m_wait_to_roll = true;
	bool m_newPlayer = true;
};

class Peach : public Avatar
{
public:
	Peach(int startX, int startY, StudentWorld* world)
		:Avatar(IID_PEACH, startX, startY, world) {}
	virtual ~Peach() {}
	virtual void doSomething() { Avatar::doSomething(1); }
};

class Yoshi : public Avatar
{
public:
	Yoshi(int startX, int startY, StudentWorld* world)
		:Avatar(IID_YOSHI, startX, startY, world) {}
	virtual ~Yoshi() {}
	virtual void doSomething() { Avatar::doSomething(2); }
};

// Coin 
class Coin : public Actor
{
public:
	Coin(int imageID, int startX, int startY, StudentWorld* world, int dir = right, int depth = 1)
		:Actor(imageID, startX, startY, world, dir, depth) {}
	virtual ~Coin() {}
	void doSomething(int coin);
	virtual void sound() const = 0;
	virtual void doSomething() = 0;

};

class BlueCoin : public Coin
{
public:
	BlueCoin(int startX, int startY, StudentWorld* world)
		:Coin(IID_BLUE_COIN_SQUARE, startX, startY, world) {}
	virtual ~BlueCoin() {}
	virtual void doSomething() { Coin::doSomething(3); }
	virtual void sound() const;
};

class RedCoin : public Coin
{
public:
	RedCoin(int startX, int startY, StudentWorld* world)
		:Coin(IID_RED_COIN_SQUARE, startX, startY, world) {}
	virtual ~RedCoin() {}
	virtual void doSomething() { Coin::doSomething(-3); }
	virtual void sound() const;
};

// Star 
class Star : public Actor
{
public:
	Star(int startX, int startY, StudentWorld* world, int dir = right, int depth = 1)
		:Actor(IID_STAR_SQUARE, startX, startY, world, dir, depth) {}
	virtual ~Star() {}
	virtual void doSomething();
};

// Direction 
class Direction : public Actor
{
public:
	Direction(int startX, int startY, StudentWorld* world, int dir = right, int depth = 1)
		:Actor(IID_DIR_SQUARE, startX, startY, world, dir, depth) {}
	virtual ~Direction() {}
	virtual void doSomething();
};

// Bank 
class Bank : public Actor
{
public:
	Bank(int startX, int startY, StudentWorld* world, int dir = right, int depth = 1)
		:Actor(IID_BANK_SQUARE, startX, startY, world, dir, depth) {}
	virtual ~Bank() {}
	virtual void doSomething();
};
/////////////////////////////////////////
// auxillary functions //////////////////
/////////////////////////////////////////


#endif // ACTOR_H_
